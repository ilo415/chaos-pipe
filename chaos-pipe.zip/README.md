# Chaos Pipe
A small Flask proxy to bypass Civitai's Cloudflare gate and forward API calls.

## Endpoints
- `/proxy/models?...`
- `/proxy/tools/search-debug`
